// FIREBASE IMPORTS
import {
    initializeApp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
    getFirestore,
    collection,
    getDocs,
    updateDoc,
    doc
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

// YOUR FIREBASE CONFIG
const firebaseConfig = {
    apiKey: "AIzaSyDaikJYguskjv2s9UDZwd1Hp2WeL7Mqlu8",
    authDomain: "odel-ca3ac.firebaseapp.com",
    projectId: "odel-ca3ac",
    storageBucket: "odel-ca3ac.appspot.com",
    messagingSenderId: "296617780816",
    appId: "1:296617780816:web:74fef090687d9e66699355",
    measurementId: "G-0LC3EPREYT"
};

// INIT
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// ------------------- LOAD USERS -------------------
async function loadUsers() {
    const tbody = document.getElementById("usersBody");
    tbody.innerHTML = "";

    // FIXED COLLECTION NAME → "users"
    const querySnapshot = await getDocs(collection(db, "users"));

    querySnapshot.forEach(docData => {
        const user = docData.data();

        const status = user.status === "frozen" ? "❄️ Frozen" : "✅ Active";
        const buttonLabel = user.status === "frozen" ? "Unfreeze" : "Freeze";

        const row = `
            <tr>
                <td>${user.email}</td>
                <td>${user.phone}</td>
                <td>${user.referralCode}</td>
                <td>${status}</td>
                <td><button onclick="toggleStatus('${docData.id}', '${user.status}')">${buttonLabel}</button></td>
            </tr>
        `;

        tbody.innerHTML += row;
    });
}

// ------------------- FREEZE / UNFREEZE -------------------
async function toggleStatus(uid, currentStatus) {
    const newStatus = currentStatus === "active" ? "frozen" : "active";

    await updateDoc(doc(db, "users", uid), {
        status: newStatus
    });

    loadUsers(); // refresh
}

// ------------------- SEARCH -------------------
async function searchUser() {
    const queryText = document.getElementById("searchBox").value.toLowerCase();
    const tbody = document.getElementById("usersBody");
    tbody.innerHTML = "";

    const querySnapshot = await getDocs(collection(db, "users"));

    querySnapshot.forEach(docData => {
        const user = docData.data();

        const emailMatch = user.email.toLowerCase().includes(queryText);
        const phoneMatch = user.phone.toLowerCase().includes(queryText);

        if (emailMatch || phoneMatch) {
            const status = user.status === "frozen" ? "❄️ Frozen" : "✅ Active";
            const buttonLabel = user.status === "frozen" ? "Unfreeze" : "Freeze";

            const row = `
                <tr>
                    <td>${user.email}</td>
                    <td>${user.phone}</td>
                    <td>${user.referralCode}</td>
                    <td>${status}</td>
                    <td><button onclick="toggleStatus('${docData.id}', '${user.status}')">${buttonLabel}</button></td>
                </tr>
            `;

            tbody.innerHTML += row;
        }
    });
}

// ------------------- INIT -------------------
document.getElementById("searchBtn").addEventListener("click", searchUser);
window.toggleStatus = toggleStatus;
loadUsers();
