document.getElementById("adminLoginBtn").addEventListener("click", function () {
  const email = document.getElementById("email").value.trim();
  const pass  = document.getElementById("password").value.trim();
  if (email === "admin@gmail.com" && pass === "123456") {
    window.location.href = "dashboard.html";
  } else { alert("Invalid admin login"); }
});
