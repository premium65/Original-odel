async function loadUsers() {
  const container = document.getElementById("userTableBody");
  container.innerHTML="";
  const snapshot = await db.collection("users").get();
  snapshot.forEach(doc=>{
    const u=doc.data(), id=doc.id;
    const tr=document.createElement("tr");
    tr.innerHTML=`
      <td>${u.name}</td>
      <td>${u.phone}</td>
      <td>${u.email}</td>
      <td>${u.depositAmount}</td>
      <td>${u.rating}</td>
      <td>${u.commission}</td>
      <td>${u.milestone}</td>
      <td style="color:${u.status==="active"?"lightgreen":"red"}">${u.status}</td>
      <td>
        <button onclick="freezeUser('${id}')">Freeze</button>
        <button onclick="unfreezeUser('${id}')">Unfreeze</button>
        <button onclick="resetRating('${id}')">Reset Rating</button>
        <button onclick="resetCommission('${id}')">Reset Commission</button>
        <button onclick="resetMilestone('${id}')">Reset Milestone</button>
      </td>`;
    container.appendChild(tr);
  });
}
async function freezeUser(id){await db.collection("users").doc(id).update({status:"frozen"}); alert("User frozen"); loadUsers();}
async function unfreezeUser(id){await db.collection("users").doc(id).update({status:"active"}); alert("User active"); loadUsers();}
async function resetRating(id){await db.collection("users").doc(id).update({rating:0}); alert("Rating reset"); loadUsers();}
async function resetCommission(id){await db.collection("users").doc(id).update({commission:0}); alert("Commission reset"); loadUsers();}
async function resetMilestone(id){await db.collection("users").doc(id).update({milestone:0}); alert("Milestone reset"); loadUsers();}
window.onload = loadUsers;
