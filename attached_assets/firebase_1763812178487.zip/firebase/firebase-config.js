// Firebase v9+ Modular SDK
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyDaiKJYguskjv2s9UDZwd1Hp2WeL7Mqlu8",
  authDomain: "odel-ca3ac.firebaseapp.com",
  projectId: "odel-ca3ac",
  storageBucket: "odel-ca3ac.firebasestorage.app",
  messagingSenderId: "296617780816",
  appId: "1:296617780816:web:74fef090687d9e66699355",
  measurementId: "G-0LC3EPREYT"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

